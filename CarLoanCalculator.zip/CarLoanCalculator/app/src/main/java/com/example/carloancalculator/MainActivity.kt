package com.example.carloancalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        buttonCalculate.setOnClickListener() {
            val Carvalue: String = editTextCarPrice.text.toString()
            val Down: String = editTextDownPayment.text.toString()
            val LoanP: String = editTextLoanPeriod.text.toString()
            val IntRate: String = editTextInterestRate.text.toString()

            val resultLoan: Double = carLoan(Carvalue, Down)
            val resultInterest: Double = interest(Carvalue, Down, IntRate, LoanP)
            val resultMonthly:Double = MonthlyPayment(Carvalue, Down ,IntRate ,LoanP)

            val realResult: String = resultLoan.toString()
            textViewValueLoan.setText(realResult)

            val realInterestValue: String = resultInterest.toString()
            textViewInterestValue.setText(realInterestValue)

            val realMonthlyValue: String = resultMonthly.toString()
            textViewMonthlyValue.setText(realMonthlyValue)
        }

        buttonReset.setOnClickListener() {
            editTextCarPrice.setText("")
            editTextDownPayment.setText("")
            editTextLoanPeriod.setText("")
            editTextInterestRate.setText("")
            textViewValueLoan.setText("")
            textViewInterestValue.setText("")
            textViewMonthlyValue.setText("")
        }

    }

        fun carLoan(Carvalue: String, Down: String): Double {
            val numCar: Double = Carvalue.toDouble()
            val numDownpayment: Double = Down.toDouble()
            val totalcarLoan: Double = numCar - numDownpayment
            return totalcarLoan
        }

        fun interest(Carvalue: String, Down: String, IntRate: String, LoanP: String): Double {
            val numCar: Double = Carvalue.toDouble()
            val numDownpayment: Double = Down.toDouble()
            val Rate: Double = IntRate.toDouble()
            val LoanDuration: Double = LoanP.toDouble()
            val totalcarLoan: Double = numCar - numDownpayment
            val totalInterest: Double = totalcarLoan * Rate * LoanDuration
            return totalInterest
        }

        fun MonthlyPayment(Carvalue: String, Down: String, IntRate: String, LoanP: String): Double {
            val numCar: Double = Carvalue.toDouble()
            val numDownpayment: Double = Down.toDouble()
            val Rate: Double = IntRate.toDouble()
            val LoanDuration: Double = LoanP.toDouble()
            val totalcarLoan: Double = numCar - numDownpayment
            val totalInterest: Double = totalcarLoan * Rate * LoanDuration
            val monthlyPay: Double = (totalcarLoan + totalInterest) / LoanDuration / 12
            return monthlyPay
        }
    }

